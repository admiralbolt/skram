package com.mojang.renderpearl.api.pipeline;

import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public enum UniformType {
    COMBINED_IMAGE_SAMPLER,
    UNIFORM_BUFFER,
    TEXEL_BUFFER;
}
