package com.mojang.renderpearl.backend.api;

import com.mojang.renderpearl.api.pipeline.ShaderType;
import com.mojang.renderpearl.util.ShaderCompileException;
import java.nio.ByteBuffer;
import java.util.List;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import org.jspecify.annotations.Nullable;

@OnlyIn(Dist.CLIENT)
public interface SpvModule extends AutoCloseable {
    @Override
    void close();

    ByteBuffer spv();

    ShaderType type();

    SpvModule.Reflection reflect() throws ShaderCompileException;

    SpvModule.@Nullable Reflection getReflectionInfoIfAvailable();

    @OnlyIn(Dist.CLIENT)
    interface Reflection {
        List<SpvModule.Reflection.InterfaceVariable> inputs();

        List<SpvModule.Reflection.InterfaceVariable> outputs();

        List<SpvModule.Reflection.Descriptor> descriptors(int resourceType);

        List<SpvModule.Reflection.Descriptor> descriptors();

        List<SpvModule.Reflection.PushConstant> pushConstants();

        @OnlyIn(Dist.CLIENT)
        interface Descriptor {
            String name();

            SpvModule.Reflection.Type type();

            int resourceType();

            int descriptorSetIndex();

            void descriptorSetIndex(int index);

            int binding();

            void binding(int location);
        }

        @OnlyIn(Dist.CLIENT)
        interface InterfaceVariable {
            String name();

            SpvModule.Reflection.Type type();

            int location();

            void location(int location);

            default boolean hasDecoration(final int decoration) {
                return this.decoration(decoration) != 0;
            }

            int decoration(int decoration);
        }

        @OnlyIn(Dist.CLIENT)
        interface PushConstant {
            int size();
        }

        @OnlyIn(Dist.CLIENT)
        interface Type {
            int baseType();

            int dimensions();

            int vectorSize();

            int arrayDimensions();

            int arrayLength(int dimensionIndex);
        }
    }
}
