@NullMarked
@OnlyIn(Dist.CLIENT)
package com.mojang.renderpearl.frontend;

import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import org.jspecify.annotations.NullMarked;
