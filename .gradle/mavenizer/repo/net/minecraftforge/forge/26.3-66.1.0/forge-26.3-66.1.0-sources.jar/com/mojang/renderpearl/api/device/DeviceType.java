package com.mojang.renderpearl.api.device;

import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public enum DeviceType {
    OTHER,
    INTEGRATED,
    DISCRETE,
    VIRTUAL,
    CPU;
}
