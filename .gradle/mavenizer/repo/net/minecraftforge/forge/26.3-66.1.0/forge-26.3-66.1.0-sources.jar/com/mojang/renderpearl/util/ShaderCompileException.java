package com.mojang.renderpearl.util;

import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class ShaderCompileException extends Exception {
    public ShaderCompileException(final String message) {
        super(message);
    }
}
