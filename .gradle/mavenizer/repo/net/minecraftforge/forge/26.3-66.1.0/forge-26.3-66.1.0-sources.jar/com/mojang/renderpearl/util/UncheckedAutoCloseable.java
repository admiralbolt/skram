package com.mojang.renderpearl.util;

import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import org.jspecify.annotations.Nullable;

@OnlyIn(Dist.CLIENT)
public interface UncheckedAutoCloseable extends AutoCloseable {
    @Override
    void close();

    static void safeClose(final @Nullable UncheckedAutoCloseable closeable) {
        if (closeable != null) {
            closeable.close();
        }
    }
}
