package com.mojang.renderpearl.api.pipeline;

import com.mojang.renderpearl.util.UncheckedAutoCloseable;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import org.jspecify.annotations.Nullable;

@OnlyIn(Dist.CLIENT)
public interface CompiledRenderPipeline extends UncheckedAutoCloseable {
    boolean isClosed();

    @FunctionalInterface
    @OnlyIn(Dist.CLIENT)
    interface Pending {
        CompiledRenderPipeline.Pending NULL = () -> null;

        @Nullable CompiledRenderPipeline finishCompile();
    }
}
