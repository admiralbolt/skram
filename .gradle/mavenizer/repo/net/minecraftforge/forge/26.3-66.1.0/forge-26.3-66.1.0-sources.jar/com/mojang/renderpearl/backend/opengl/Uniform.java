package com.mojang.renderpearl.backend.opengl;

import com.mojang.renderpearl.api.GpuFormat;
import com.mojang.renderpearl.util.UncheckedAutoCloseable;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public sealed interface Uniform extends UncheckedAutoCloseable permits Uniform.Sampler, Uniform.Ubo, Uniform.Utb {
    @Override
    default void close() {
    }

    @OnlyIn(Dist.CLIENT)
    record Sampler(int samplerIndex) implements Uniform {
    }

    @OnlyIn(Dist.CLIENT)
    record Ubo(int blockBinding) implements Uniform {
    }

    @OnlyIn(Dist.CLIENT)
    record Utb(int samplerIndex, GpuFormat format, int texture) implements Uniform {
        public Utb(final int samplerIndex, final GpuFormat format) {
            this(samplerIndex, format, GlStateManager._genTexture());
        }

        @Override
        public void close() {
            GlStateManager._deleteTexture(this.texture);
        }
    }
}
