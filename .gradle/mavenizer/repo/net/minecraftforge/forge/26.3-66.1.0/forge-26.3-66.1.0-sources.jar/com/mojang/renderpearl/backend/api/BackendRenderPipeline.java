package com.mojang.renderpearl.backend.api;

import com.mojang.renderpearl.api.GpuFormat;
import com.mojang.renderpearl.api.pipeline.BindGroupLayout;
import com.mojang.renderpearl.api.pipeline.ColorTargetState;
import com.mojang.renderpearl.api.pipeline.DepthStencilState;
import com.mojang.renderpearl.api.pipeline.PolygonMode;
import com.mojang.renderpearl.api.pipeline.PrimitiveTopology;
import com.mojang.renderpearl.util.UncheckedAutoCloseable;
import java.util.List;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import org.jspecify.annotations.Nullable;

@OnlyIn(Dist.CLIENT)
public interface BackendRenderPipeline extends UncheckedAutoCloseable {
    boolean isClosed();

    @OnlyIn(Dist.CLIENT)
    record CreateInfo(
        String name,
        List<BackendRenderPipeline.CreateInfo.Shader> shaders,
        List<BackendRenderPipeline.CreateInfo.VertexBuffer> vertexBuffers,
        List<BackendRenderPipeline.CreateInfo.AttribBinding> attribBindings,
        List<BindGroupLayout.UniformDescription> uniforms,
        int pushConstantsSize,
        @Nullable DepthStencilState depthStencilState,
        PolygonMode polygonMode,
        boolean cull,
        List<@Nullable ColorTargetState> colorTargetStates,
        PrimitiveTopology primitiveTopology
    ) {
        @OnlyIn(Dist.CLIENT)
        public record AttribBinding(int bufferSlot, int location, int offset, GpuFormat format) {
        }

        @OnlyIn(Dist.CLIENT)
        public record Shader(String name, String entryPoint, SpvModule module) {
        }

        @OnlyIn(Dist.CLIENT)
        public record VertexBuffer(int bufferSlot, int stride, int stepRate) {
        }
    }

    @FunctionalInterface
    @OnlyIn(Dist.CLIENT)
    interface Pending {
        BackendRenderPipeline.Pending NULL = () -> null;

        @Nullable BackendRenderPipeline finishCompile();
    }
}
