@NullMarked
@OnlyIn(Dist.CLIENT)
package com.mojang.renderpearl.api.device;

import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import org.jspecify.annotations.NullMarked;
