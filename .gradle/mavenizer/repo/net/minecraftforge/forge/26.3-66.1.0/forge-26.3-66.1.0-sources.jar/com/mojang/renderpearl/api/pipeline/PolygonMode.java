package com.mojang.renderpearl.api.pipeline;

import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public enum PolygonMode {
    FILL,
    WIREFRAME;
}
